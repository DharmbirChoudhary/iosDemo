//
//  ControllerProxy.m
//  Controller
//
//  Created by lws on 14-8-24.
//  Copyright (c) 2014年 lws. All rights reserved.
//

#import "ControllerProxy.h"

@implementation ControllerProxy

@end
