//
//  DvdViewController.h
//  Controller
//
//  Created by lws on 14-8-24.
//  Copyright (c) 2014年 lws. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUDManager.h"

@interface DvdViewController : UIViewController
@property (nonatomic,strong) MBProgressHUDManager *HUDManager;

@end
